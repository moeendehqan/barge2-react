


const ImageToText = () =>{
    return(
        <div className="sub">

        </div>

    )
}

export default ImageToText