import axios from "axios"
import { useEffect, useState } from "react"
import { OnRun } from "../../config/OnRun"
import MsgInPage from "../../componets/msg/MsgInPage"
import { getCookie, setCookie } from "../../function/cookie"
import { useNavigate } from "react-router-dom"
import { MdOutlineMan , MdOutlineWoman2 } from "react-icons/md";
import Button from "react-multi-date-picker/components/button"
import DatePicker, { DateObject } from "react-multi-date-picker"
import persian from "react-date-object/calendars/persian"
import persian_fa from "react-date-object/locales/persian_fa"

const Price = ()=>{

    const [msg,setMsg] = useState('')
    const [user,setUser] = useState({type:'حقیقی',phone:'',sex:'مرد'})
    const navigate = useNavigate()

    const getUserByPUA = () =>{
        axios({method:'POST',url:OnRun+'/getuserbypua',data:{pua:getCookie('pua')}
        }).then(response=>{
            if(response.data.replay){
                if (Object.keys(response.data.user).includes('dateBirth')) {
                    response.data.user.dateBirth = new DateObject(new Date(response.data.user.dateBirth))
                }
                setUser(response.data.user)
            }else{
                navigate('/')
            }
        })
    }


    const applyProfile = () =>{
        if ((user.type=='حقیقی') && (!(user.fullname) || user.fullname=='')) {setMsg('نام را وارد کنید')
        }else if((user.type=='حقیقی') && !(user.sex)) {setMsg('جنسیت را مشخص کنید')
        }else if((user.type=='حقیقی') && !(user.dateBirth)) {setMsg('تاریخ تولد را انتخاب کنید')
        }else if((user.type=='حقیقی') && !(user.email)) {setMsg('لطفا ایمیل را وارد کنید')
        }else if((user.type=='حقوقی') && (!(user.companyName) || (user.companyName==''))){setMsg('لطفا نام شرکت را وارد کنید')
        }else if((user.type=='حقوقی') && (!(user.nationalId) || (user.nationalId==''))){setMsg('لطفا شناسه ملی را وارد کنید')
        }else if((user.type=='حقوقی') && (!(user.registerId) || (user.registerId==''))){setMsg('لطفا شماره ثبت را وارد کنید')
        }else if((user.type=='حقوقی') && (!(user.address) || (user.address==''))){setMsg('لطفا آدرس را وارد کنید')
        }else if((user.type=='حقوقی') && (!(user.postCode) || (user.postCode==''))){setMsg('لطفا کد پستی را وارد کنید')
        }else if((user.type=='حقوقی') && (!(user.email) || (user.email==''))){setMsg('لطفا ایمیل را وارد کنید')
        }else{
            axios({method:'POST',url:OnRun+'/setprofile',data:user
            }).then(response=>{
                console.log(response.data)
            })
        }
    }


    useEffect(getUserByPUA,[])
    return(
        <div className="pghlf">
            <section>
                <h2>تعرفه ها</h2>
                <button onClick={applyProfile}>ثبت</button>
            </section>
            <img src="/img/loginVector.svg" />


        </div>
    )
}

export default Price